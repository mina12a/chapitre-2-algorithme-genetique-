package com.company;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class OperationGA  extends AlgoGene{

    private   static final int nbchro = 0;
    private  static final double tauxcroiss = .95;
    private static final int taille = 30;
    private static final double tauxmutation = .05;

    /**************************************les operation de GA  cross***********************************/

    public static void crossOver() {// croisement
        List<Chromosom> newpop = new ArrayList<>();
        //Bendekoum Amina
        Chromosom selectionA, selectionB;
        for (int i = 0; i < nbchro; i++) { // conserver les solutions pere
            newpop.add(getPopulation().getChromosom().get(i));
        }
        for (int i = nbchro; i < Population.N; i++) {
            if (Math.random() < tauxcroiss) {
                selectionA = selectChromosom().get(0); // selectioner A
                selectionB = selectChromosom().get(0); // selectioner B
                newpop.add( crossOverChromosom(selectionA, selectionB)); // mutation entre la meilleur sol du a et la meilleur du b
            } else {
                newpop.add(population.getChromosom().get(i)); // ajout a la nouvelle population

            }
        }
        getPopulation().setChromosom(newpop);
    }


    /***************************************les operation de GA mutat ***********************************/

    public static void mutate() { // mutaiton
        List<Chromosom> newpop = new ArrayList<>();
        for (int i = 0; i < nbchro; i++) { // conserver les solutions pere
            newpop.add(getPopulation().getChromosom().get(i));
        }
        for (int i = nbchro; i < Population.N; i++) { // applique la mution sur toute la population
            newpop.add(mutateChromosom(population.getChromosom().get(i)));
        }
        getPopulation().setChromosom(newpop); // ecraser ancienne population
        if (getPopulation().getChromosom().get(0).getFitness() > solBest.getFitness()) {
            solBest = getPopulation().getChromosom().get(0); // calcule de la meilleur solution
        }
    }

    /***************************************les operation de GA Cross ***********************************/
    public static Chromosom crossOverChromosom(Chromosom chrom1, Chromosom chrom2) {

        int[] genes = new int[Drive.nbvar];

        for (int i = 0; i < Drive.nbvar; i++) {
            if (0.5 > Math.random()) {
                genes[i] = chrom1.getGene()[i];
            } else {
                genes[i] = chrom2.getGene()[i];
            }
        }
        return new Chromosom();
    }

    /***************************************les operation de GA Mutate ***********************************/
    public static Chromosom mutateChromosom(Chromosom indi) { // mutation entre 2 chromosome
        int[] genes = new int[Drive.nbvar];
        for (int i = 0; i < Drive.nbvar; i++) {

            if (tauxmutation > Math.random()) {
                if (indi.getGene()[i] == 0) {
                    genes[i] = 1;
                } else {
                    genes[i] = 0;
                }
            } else {
                genes[i] = indi.getGene()[i];
            }
        }
        return new Chromosom();
    }

    /***************************************les operation de GA Select ***********************************/
    public static List<Chromosom> selectChromosom() { // fonction de selection aleatoire
        List<Chromosom> Chro = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < taille; i++) {
            Chromosom c = getPopulation().getChromosom().get(random.nextInt(Population.N));
            if (!Chro.contains(c)) {
                Chro.add(c);
            } else {
                i--;
            }
        }
        Chro.sort(new NvFitness());
        return Chro;
    }
}




/***************************************fin***********************************/

