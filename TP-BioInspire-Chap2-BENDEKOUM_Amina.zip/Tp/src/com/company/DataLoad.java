package com.company;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class DataLoad extends Drive{



    /*************  Chargement d'un fichie*****************************************/

    public static <Chromosom> Chromosom BDDSat(String fileName) {

        mclause = new ArrayList<>();
        int tmp;

        try {
            //Bendekoum Amina
            InputStream sp = new FileInputStream(System.getProperty("user.dir") + fileName);
            InputStreamReader ir = new InputStreamReader(sp);
            BufferedReader bfr = new BufferedReader(ir);
            String line;
            String[] lit;

            boolean first = true;
            while ((line = bfr.readLine()) != null) {
                if (line.startsWith("c") || line.startsWith("%") || line.startsWith("0") || line.equals("")) {
                } else {
                    if (line.startsWith("p")) {
                        line = line.replace("p cnf ", "");
                        line = line.replaceFirst(" ", "");
                        lit = line.split(" ");
                        nbvar = Integer.parseInt(lit[0]);
                        int nbclause = Integer.parseInt(lit[1]);
                        continue;
                    }
                    litt = new ArrayList<Literals>();
                    if (first) {
                        line = line.replaceFirst(" ", "");
                        first = false;
                    }
                    lit = line.split(" ");
                    for (int i = 0; i < 3; i++) {
                        tmp = Integer.parseInt(lit[i]);
                        if (tmp > 0) {
                            litteral = new Literals(tmp, 1);
                        } else {
                            litteral = new Literals(-tmp, -1);
                        }
                        litt.add(litteral);
                    }
                    clause = new Clause(litt);
                    mclause.add(clause);
                }
            }
            bfr.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return (Chromosom) new Individu(mclause);
    }
}
