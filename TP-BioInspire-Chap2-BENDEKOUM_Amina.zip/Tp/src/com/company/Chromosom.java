package com.company;

import java.util.Arrays;
import java.util.Random;

public class Chromosom {

    private int[] gene;
    private int fitness;



    /**************** *****************  constructeur   **************************************/

    public Chromosom(int[] gene) {

        int fitnessf = Satisfiable.satisfiClause(gene);
        int [ ]genee =gene.clone();
        //Bendekoum Amina
        /****/
        this.gene =genee ;
        fitness = fitnessf;
    }
    /***************************************               ****************************/
    public Chromosom() {

        Random ran = new Random();
        gene = new int[Drive.nbvar];
        for (int i = 0; i < Drive.nbvar; i++) {
            gene[i] = ran.nextInt(2);
        }
        fitness = Satisfiable.satisfiClause(gene);
    }

    /**************** *****************  getter et setter  **************************************/
    public int[] getGene() { return gene; }

    public int getFitness() { return fitness; }

    public void setGene(int[] gene) { this.gene = gene;}

    public void setFitness(int fitness) { this.fitness = fitness; }

    public String toString() { return  Arrays.toString(gene); }
}

/**************** ***************** fin *********************************************************/