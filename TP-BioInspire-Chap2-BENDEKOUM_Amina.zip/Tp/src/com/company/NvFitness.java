package com.company;


import java.util.Comparator;
import java.util.Random;



public class NvFitness implements Comparator<Chromosom> {

    /*****************   la methode compare  **************************************************/
    @Override
    public int compare(Chromosom chr1, Chromosom chr2) {
        //Bendekoum Amina
        return chr2.getFitness() - chr1.getFitness();
    }
}
/*****************   ********************* **************************************************/