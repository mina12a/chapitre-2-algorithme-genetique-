package com.company;

public class Literals {


        private int var;
        private int valeur;
    /**************** *****************  constructeur   **************************************/

        public Literals(int var, int valeur) { this.var = var; this.valeur = valeur; }

    /**************** *****************  getter et setter  **************************************/
    //Bendekoum Amina
    public int getVar() { return var; }
        public int getValeur() { return valeur; }
        public void setVar(int var) {this.var = var; }
        public void setValeur(int valeur) { this.valeur = valeur;}
        public int getLiteralsValeur(int x) { if (this.valeur == 1) { return x; }
                                              else { if (x== 1) { return 0; }
                                              else { return 1; }
                                                   }
                                                   }
        public int getLiteralsVar() {
                                      int y =var * -1;
                                      if (this.valeur == 1) { return var; }
                                      return y; }
                                     }
/*************************** fin ***************************************************************************/