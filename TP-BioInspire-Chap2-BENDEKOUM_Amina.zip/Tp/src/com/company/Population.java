package com.company;

import java.util.ArrayList;
import java.util.List;

public class Population {

    private int taillePop ;
    public static final int N= 75;
    private List<Chromosom> chromosome;
    //Bendekoum Amina
/**********************************************************************************************************/
    public Population() {
                        chromosome = new ArrayList<>();
                        this.taillePop = N;
                         for (int i = 0; N>i; i++)
                         { chromosome.add(new Chromosom()); }
                         NvPopulation(); }

/*********************   setter et getter    ************************************************************************/
    public void NvPopulation() { chromosome.sort(new NvFitness()); }
    public List<Chromosom> getChromosom() { return chromosome;}
    public void setChromosom(List<Chromosom> chromosome) { this.chromosome = chromosome;NvPopulation(); }
    public int getBestFitness(){ return chromosome.get(0).getFitness(); }// return le chromosome
}
/*************************** fin ***************************************************************************/