package com.company;

import java.util.List;

public class Individu extends Chromosom {
    //Bendekoum Amina
    private List<Clause> mclause;
    /**************** *****************  constructeur   **************************************/

    public Individu(List<Clause> mclause) {
        this.mclause = mclause;
    }

    /**************** *****************  getter et setter  **************************************/

    public List<Clause> getClause() { return mclause;}
    public void setClause(List<Clause> mclause) { this.mclause = mclause; }
}


/***********************************************************************************/