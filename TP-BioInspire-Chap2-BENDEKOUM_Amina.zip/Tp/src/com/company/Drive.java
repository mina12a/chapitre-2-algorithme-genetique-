package com.company;

import java.util.List;

import static com.company.DataLoad.BDDSat;

public class Drive {

    public static List<Clause> mclause;
    public static int nbvar;
    private static int nbclause;
    public static final int time = 5000;
    public static long debutmp;
    public static long totaltmp = 0;
    public static List<Literals> litt;
    public static Literals litteral;

    public static Clause clause;
    public static Chromosom satt;


    public static void main(String[] args) {

        AlgoGene geneticAlgo;
        //Bendekoum Amina
        for (int i = 1; i <= 100; i++) { // pour les 100 instances

            satt = BDDSat("/res/uf75-325/uf75-0" + i + ".cnf");
            geneticAlgo = new AlgoGene();
            debutmp = System.currentTimeMillis();// temps de debut
            while (System.currentTimeMillis() - debutmp < time) {
                OperationGA.crossOver(); // croisement
                OperationGA.mutate(); // nmutation
            }

            printChromosom(i, geneticAlgo); // affichage de la solution

        }
        System.out.println("Total Time : " + totaltmp + "ms");
        System.out.println("--------------------------------------------");
    }

    /********Affichage de resultas de lameilleur solution *******/

    public static String printChromosom(int iteration, AlgoGene geneticAlgo) {
        long elapsedTime = System.currentTimeMillis() - debutmp;
        totaltmp = totaltmp + elapsedTime;
        System.out.println("Cette production a été développée et testée dans un " +
                "environnement Windows 10 sous Java  avec l'application IntelliJ IDEA.");
        System.out.println("*************************************************");
        System.out.println(" iteration : # " + iteration + "\n" + " / le meilleur chromosome est :" + "\n"
                + geneticAlgo.getBest().toString()
                + "\n" + " /  Fitness :" + geneticAlgo.getBest().getFitness());
        System.out.println("*************************************************");
        System.out.println(" /le temp : " + elapsedTime + "ms");

        return " iteration : # " + iteration + "\n" + " / le meilleur chromosome est :" + "\n"
                + geneticAlgo.getBest().toString()
                + "\n" + " /  Fitness :" + geneticAlgo.getBest().getFitness() + "/le temp : " + elapsedTime + "ms";
    }

    /*************************  *** getter et setter *************************************************/
    public int getNbClause() {
        return nbclause;
    }

    public void setNbClauses(int nbclause) {
        this.nbclause = nbclause;
    }

    public int getNbVar() {
        return nbvar;
    }
/**************************************************************************************************/


}


