package com.company;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class AlgoGene {

    public static Population population;
    public static Chromosom solBest = null;


    /**************** *****************  constructeur   **************************************/
    public AlgoGene() {
        //Bendekoum Amina
        this.population = new Population();
        solBest = (Chromosom) this.population.getChromosom().get(0);
    }

    /**************** *****************  setter et getter   **************************************/
    public Chromosom getBest() {
        return this.solBest;
    }

    public static Population getPopulation() {
        return population;
    }

    public void setPopulation(Population population) {
        this.population = population;
    }


}
/**************** ***************** ***********   **************************************/
