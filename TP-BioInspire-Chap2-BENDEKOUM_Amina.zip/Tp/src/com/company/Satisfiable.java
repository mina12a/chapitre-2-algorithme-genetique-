package com.company;

public class Satisfiable {

    /********************************************** -1-*************************************/
    public static int satisfiClause(int[] gene) {
        int satte = 0;
        for (Clause c : Drive.mclause) {
            for (Literals l : c.getLiteral()) {
                if (l.getLiteralsValeur(gene[l.getVar() - 1]) == 1)
                { satte++;
                    break;
                }
            }
        }
        return satte;
    }
    /********************************************** -1-    *******************************************/
    public boolean satisfi(Chromosom chro)
    { int[] gene = chro.getGene();
        boolean satis = false;
        for (Clause c : Drive.mclause) { satis = false;
            for (Literals l : c.getLiteral())
            { if (l.getLiteralsValeur(gene[l.getVar() - 1]) == 1)
            { satis = true; }
            }
            if (!satis) { return false;}
        }
        return true;
    }
}
/********************************************************************************************/