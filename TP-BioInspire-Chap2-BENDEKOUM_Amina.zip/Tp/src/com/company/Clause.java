package com.company;

import java.util.List;


public class Clause {

    private List<Literals> litter;

    /**************** *****************  constructeur   **************************************/
          public Clause() { }
          public Clause(List<Literals> litter)           { this.litter = litter; }

    /**************** *****************  getter et setter  **************************************/
    //Bendekoum Amina
          public void setLiteral(List<Literals> litter)   {this.litter = litter;}
          public List<Literals> getLiteral()              { return litter; }

                    }

/**************** ************************* fin *******************************************************/